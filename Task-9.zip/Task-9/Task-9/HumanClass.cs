﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task_9
{
    class HumanClass: IStudentWorker
    {
        string name;

        public HumanClass(string name)
        {
            Name = name;
        }

        public HumanClass(string name, int payment, int salary)
        {
            Name = name;
            this.payment = payment;
            this.salary = salary;
        }

        public string Name { get => name; set => name = value; }
        public int payment { get; set; }
        public int salary { get; set; }
    }
    interface IStudent
    {
        int payment { get; set; }
        void pay(int pay)
        {
            payment = pay;
        }
    }
    class Student
    {
        int payment { get; set; }
        void pay(int pay)
        {
            payment = pay;
        }
    }
    interface IWorker
    {
        int salary { get; set; }
        void SalaryWorker(int Salary)
        {
            salary = Salary;
        }
    }
    class Worker
    {
        int salary { get; set; }
        void SalaryWorker(int Salary)
        {
            salary = Salary;
        }
    }
    interface IStudentWorker : IWorker, IStudent
    {
        public int payment { get; set; }
        public int salary { get; set; }
    }
    class StudentWorker
    {
        public int payment { get; set; }
        public int salary { get; set; }
        void SalaryWorker(int Salary)
        {
            salary = Salary;
        }
        void pay(int pay)
        {
            payment = pay;
        }
    }
}
